#!/bin/bash

if [ $# -lt 1 ] ; then
    echo Expected name of vtk file
    exit 1
fi


totpt=0
for vtk in $*
do
  echo "! file: $vtk"
  first_line=$(head -n 1 $vtk)
  npt=$(echo $first_line | cut -d ' ' -f1)
  ntet=$(echo $first_line | cut -d ' ' -f1)
  echo "! npt=$npt, ntet=$ntet"
  l=0
  first=t
  while read s
  do
      if [ $first = t ] ; then
         first=f
      else
         if [ $l -le $npt ] ; then
            echo pt $(($l+$totpt)) $s
         else
            toks=$(echo $s)
            n0=$(echo $toks | cut -d ' ' -f1)
            n1=$(echo $toks | cut -d ' ' -f2)
            n2=$(echo $toks | cut -d ' ' -f3)
            n3=$(echo $toks | cut -d ' ' -f4)
            echo 0 $(($n0+$totpt+1)) $(($n1+$totpt+1)) $(($n2+$totpt+1)) $(($n3+$totpt+1)) 1
         fi
      fi
      l=$(($l+1))
  done < $vtk
  totpt=$(($totpt+$npt))
  echo "! totpt=$totpt"
done
