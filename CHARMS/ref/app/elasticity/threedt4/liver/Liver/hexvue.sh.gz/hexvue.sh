#! /bin/bash

prob=$1; shift
if [ $# -ge 1 ] ; then
  step=$1; 
  hvufile=$prob-adapt$step.hvu
else
  step=
  hvufile=$prob.hvu
fi
hexvuefile=$prob.hexvue

cat <<EOF > $hexvuefile
! 
NEWFRAME WIDTH 480 HEIGHT 480 X 100 Y 100
edgeflag on
edgecolor white
shrink 1
hvuchattribs
hvuload $hvufile
!
HVUPICKSET 2 ! z
HVUSETDISP 0 1 2 sxsysz 1 1 1
! 
! load liver4.egf
fill solid
hvucutc  0.0766855 0.158511 0.15
hvucutn 1 0 0
hvucrcut
hvucutn 0 1 0
hvucrcut
hvucutn 0 0 1
hvucrcut
layer off 0 ! turn off the filled mesh
view axes on
view bground grey50
view load liver4.view
fit
layer on   0
layer on   1
layer off 15
layer on  16
layer 0
!
render ldir -1 2 3
RENDER SHADE
! fringe 1 18
fit
! HVUQUIT
EOF


hexvue -c $hexvuefile 
rm -f $hexvuefile
